<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\M_note;

class C_note extends BaseController
{
  protected $M_note;

  public function __construct()
  {
    $this->model = new M_note();
  }

  // Dashboard
  public function index()
  {
    return view('dashboard');
  }

  // Create Note
  public function create_note()
  {
    return view('createNote');
  }

  // List Note
  public function list_note()
  {
    $data = ['note' => $this->model->getAllNote()];
    // echo '<pre>';
    // print_r($data);
    return view('listNote', $data);
  }

  // Save Note
  public function save_note()
  {
    if (isset($_GET)) {
      $data = [
        'id'   => $_GET['id'],
        'title' => $_GET['title'],
        'note' => $_GET['note'],
        'user' => 'Saya',
      ];

      $this->model->saveNote($data);
    }
  }
}
