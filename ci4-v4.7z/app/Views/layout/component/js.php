<script>
  // ===== Menginisialisasi =====

  // Text Editor Summernote
  $('#summernote').summernote({
    placeholder: 'Tulis catatan',
    tabsize: 2,
    toolbar: [
      ['style', ['bold', 'italic', 'underline', 'clear']],
      ['font', ['strikethrough', 'superscript', 'subscript']],
      ['fontsize', ['fontsize']],
      ['color', ['color']],
      ['para', ['ul', 'ol', 'paragraph']],
      ['height', ['height']]
    ],
    height: 'fit-content',
    minHeight: 100,
  });


  const Toast = Swal.mixin({
    toast: true,
    position: 'bottom-end',
    showConfirmButton: false,
    timer: 3000,
    timerProgressBar: true,
    didOpen: (toast) => {
      toast.addEventListener('mouseenter', Swal.stopTimer)
      toast.addEventListener('mouseleave', Swal.resumeTimer)
    }
  })



  // ===== Code =====

  let id = "";
  let title = "";
  let data_note = "";
  let typingTimer;

  if ($("#idNote").val() == "") {
    $("#titleNote").change(function() {
      title = $(this).val();

      $("#idNote").val("<?= uniqid() ?>");
      id = $("#idNote").val();
    })
  } else {
    $("#titleNote").change(function() {
      title = $(this).val();
    })
  }



  $('#summernote').on('summernote.change', function(we, contents, $editable) {
    if ($("#titleNote").val() == "") {
      console.log("Title belum diisi!")
    } else {
      clearTimeout(typingTimer);
      $(".lds-ellipsis").removeClass('d-none');
      typingTimer = setTimeout(function() {
        sendNote(contents)
          .then((data) => {
            console.log(data);
            $(".lds-ellipsis").addClass('d-none');
            Toast.fire({
              icon: 'success',
              title: 'Note sudah tersimpan',
            })
          })
          .catch((error) => {
            console.log(error);
            $(".lds-ellipsis").addClass('d-none');
          })
      }, 2000);
    }
  });

  if ($("#idNote").val() !== "") {
    $("#titleNote").change(function() {
      console.log('masih ada id');
    })
  }

  async function sendNote(data) {
    return new Promise((resolve, reject) => {
      $.ajax({
        url: "http://localhost:8080/note/save",
        type: 'GET',
        data: {
          id: id,
          title: title,
          note: data
        },
        success: function(data) {
          resolve("berhasil");
        },
        error: function(error) {
          reject("gagal");
        },
      });
    })
  }
</script>