<?= $this->extend('layout/template') ?>

<?= $this->section('content') ?>
<!-- Page Heading -->
<h1 class="h3 mb-4 text-gray-800">Type Note</h1>

<div class="row">
  <div class="card col-xl-10 col-md-12 py-4 border">
    <div class="d-flex justify-content-between align-items-center">
      <div class="col-md-6 ml-0">
        <input type="text" class="d-none" id="idNote" value="">
        <input type="text" class="form-control" id="titleNote" placeholder="Nama note" aria-label="Nama note">
      </div>

      <div class="loading">
        <div class="d-none lds-ellipsis"><div></div><div></div><div></div><div></div></div>
      </div>
    </div>

    <form class=" col-md-12" method="post">
      <textarea id="summernote" name="editordata"></textarea>
    </form>
  </div>
</div>
<?= $this->endSection(); ?>