<?php

namespace App\Models;

use CodeIgniter\Model;

class M_note extends Model
{
  protected $table      = 'note';
  protected $primaryKey = 'id';

  protected $useAutoIncrement = false;

  protected $returnType     = 'array';
  protected $useSoftDeletes = false;

  protected $allowedFields = ['id', 'title', 'note', 'user'];

  protected $useTimestamps = true;
  protected $createdField  = 'created_at';
  protected $updatedField  = 'updated_at';
  protected $deletedField  = 'deleted_at';

  public function __construct()
  {
    $db = \Config\Database::connect();
    $this->builder = $db->table('note');
  }

  public function getAllNote() {
    $query = $this->builder->get()->getResultArray();
    return $query;
  }

  public function saveNote($data)
  {
    if ($this->builder->where('id', $data['id'])) {
      $this->builder->update($data, ['id' => $data['id']]);
    } else {
      $this->builder->insert($data);
    }
      // $this->builder->set($data);
      // $this->builder->insert();
  }
}
