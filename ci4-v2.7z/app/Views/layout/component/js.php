<script>
  // ===== Menginisialisasi =====

  // Text Editor Summernote
  $('#summernote').summernote({
    placeholder: 'Tulis catatan',
    tabsize: 2,
    height: 100,
    toolbar: [
      ['style', ['bold', 'italic', 'underline', 'clear']],
      ['font', ['strikethrough', 'superscript', 'subscript']],
      ['fontsize', ['fontsize']],
      ['color', ['color']],
      ['para', ['ul', 'ol', 'paragraph']],
      ['height', ['height']]
    ],
  });


  // ===== Code =====

  // Input name on change simpan array[title]
  // - Jika id belum ada, maka saat sendNote() id uniqid di model
  // - Jika id sudah ada, maka sendNote hanya akan update di model

  // Input text editor setiap huruf akan selalu update ke database
  // dengan menggabungkan id, title, note


  let id = ""
  let title = "";
  let data_note = "";

  if ($("#idNote").val() == "") {
    $("#titleNote").change(function() {
      title = $(this).val();

      $("#idNote").val("<?= uniqid() ?>");
      id = $("#idNote").val();
    })
  } else {
    $("#titleNote").change(function() {
      title = $(this).val();
    })
  }


  $('#summernote').on('summernote.change', function(we, contents, $editable) {
    if ($("#titleNote").val() == "") {
      console.log("Title belum diisi!")
    } else {
      sendNote(contents)
        .then((data) => {
          console.log(data);
        })
        .catch((error) => {
          console.log(error);
        })
    }
  });

  function sendNote(data) {
    return new Promise((resolve, reject) => {
      $.ajax({
        url: "http://localhost:8080/note/save",
        type: 'GET',
        data: {
          id: id,
          title: title,
          note: data
        },
        success: function(data) {
          resolve(data);
        },
        error: function(error) {
          reject("gagal");
        },
      });
    })
  }
</script>