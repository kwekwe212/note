<?= $this->extend('layout/template') ?>

<?= $this->section('content') ?>
<!-- Page Heading -->
<h1 class="h3 mb-4 text-gray-800">Tambah Note</h1>

<div class="row">
  <div class="card col-xl-8 col-md-6 py-4 border">
    <div class="input-group col-md-6 ml-0 mb-4">
      <input type="text" class="form-control" placeholder="Nama note" aria-label="Recipient's username" aria-describedby="button-addon2">
      <div class="input-group-append">
        <button class="btn btn-outline-success" type="button" id="button-addon2">Button</button>
      </div>
    </div>

    <form class="col-md-12" method="post">
      <textarea id="summernote" name="editordata"></textarea>
    </form>
  </div>
</div>
<?= $this->endSection(); ?>