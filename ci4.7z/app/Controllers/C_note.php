<?php

namespace App\Controllers;

class C_note extends BaseController
{
  // Dashboard
  public function index()
  {
    return view('dashboard');
    // echo base_url('assets/css/sb-admin-2.css');
  }

  // Create Note
  public function create_note()
  {
    return view('createNote');
    // echo "Tambah note";
  }
}
